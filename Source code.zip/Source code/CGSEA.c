#include <stdio.h>
#include <iostream>
#include <string>
#include <fstream>
#include <stdlib.h>

using namespace std;
int main(int argc, char* argv[])
{

//Input parameters
int simutime=1000,max=200,min=5,cp=1,Dgene=1,TType=1,PType=1,geneP=2,PCAnum=3;
float w1=0.5,w2=0.5;
char output[200],str[400];
ofstream logfile("./log.txt");
ofstream temp("./temp.txt");
fstream _file;

printf("@-----------------------------------------------------------@\n");
printf("|           CGSEA        |     v1.0      |    1/May/2019   |\n");
printf("|-----------------------------------------------------------|\n");
printf("|                 Feng Zhang, Xi'an Jiaotong University     |\n");
printf("@-----------------------------------------------------------@\n");
printf("\n");
printf("Analyzing parameters will be output to \"log.txt\"\n");
printf("\n");



printf("Please enter the Chemical-gene annotation file name:\n");
cin>>output;
logfile<<"Chemical-gene annotation file:";
logfile<<output<<endl;
temp<<output<<endl;
_file.open(output,ios::in);
if(!_file)
     {
cout<<"File does not exits!";
system("rm ./temp.txt");
return 0;
}
_file.close();


printf("Please enter the gene expression association testing statistic file name:\n");
cin>>output;
logfile<<"gene expression association testing statistic file name:";
logfile<<output<<endl;
temp<<output<<endl;

_file.open(output,ios::in);
if(!_file)
     {
cout<<"File does not exits!";
system("rm ./temp.txt");
return 0;
}
_file.close();


printf("Please enter permutation times [fault value=1000]:\n");
cin>>simutime;
if(simutime<1)
   {
printf("Your input is incorrect!\n");
system("rm ./temp.txt");
return 0;
   }
logfile<<"Permutation times:";
logfile<<simutime<<endl;
temp<<simutime<<endl;

printf("Please enter maximum size of analyzed pathways [fault value=500]:\n");
cin>>max;
if(max<1||max>10000)
   {
printf("Your input is incorrect!\n");
system("rm ./temp.txt");
return 0;
   }
temp<<max<<endl;

printf("Please enter minimum size of analyzed pathways [fault value=5]:\n");
cin>>min;
if(min<1||min>10000||min>max)
   {
printf("Your input is incorrect!\n");
system("rm ./temp.txt");
return 0;
   }
logfile<<"Pathway sizes:";
logfile<<min<<"-"<<max<<" genes"<<endl;
temp<<min<<endl;

logfile.close();
temp.close();
printf("-------------------------------------------------------------\n");
printf("Analysis is running now, please wait.\n");
system("mkdir permu");

sprintf(str,"R -f ./cal --quiet >> Output.temp");
system(str);

system("rm ./temp.txt");
system("rm ./Output.temp");
system("rm ./Chelist.txt");
system("rm -r ./permu");

}
